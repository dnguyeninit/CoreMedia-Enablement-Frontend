/**
 * CoreMedia namespace
 * @namespace
 * @ignore
 */
var coremedia = (function (module) {
  return module;
}(coremedia || {}));
/**
 * CoreMedia Blueprint namespace
 * @namespace
 * @ignore
 */
coremedia.blueprint = (function (module) {
  /*global jQuery*/
  module.$ = module.$ || jQuery;
  return module;
}(coremedia.blueprint || {}));

(function ($) {
  "use strict";

  /**
   * jQuery Plugin that hooks into Bootstrap carousel functionality via the `slid.bs.carousel` to add
   * Responsive Image Resizer Plugin and pagination.
   *
   * @function "coremedia.blueprint.$.fn.cmCarousel"
   * @summary jQuery Plugin that hooks for Bootstrap carousel
   * @example
   * CoreMedia carousels can be automatically initialized simply by adding the data attribute `data-cm-carousel`
   * to your carousel container element.
   * ```html
   * <div class="cm-carousel carousel slide" data-cm-carousel='{"interval":"6000"}' ...
   * ```
   * CoreMedia will automatically find and initialize a carousel for any element that contains this data attribute.
   * If you do not want this behavior then do not add the data attribute to your carousel and instead initalize the
   * carousel programmatically by invoking the method on the carousel container element:
   * ```javascript
   * $('[data-cm-carousel]').cmCarousel();
   * ```
   * Auto-initialization is not supported for carousels that are added to the DOM after jQuery's ready event has
   * fired. In this case you will need to programatically initialize your carousel by invoking the method as shown
   * above.
   *
   * The carousel can be configured by assigning an object with the following properties to the `data-cm-carousel`
   * attribute.
   *
   * | Name | Type | Default | Description |
   * | --- | --- | --- | --- |
   * | pause | <code>boolean</code> | <code>false</code> | Pause the carousel from sliding, if needed. |
   * | interval | <code>number</code> | <code>5000</code> | Interval used for each sliding. |
   */
  $.fn.cmCarousel = function () {

    return this.each(function () {

      var $carousel = $(this);

      var data = $carousel.data('cm-carousel');
      // pause the carousel from sliding if needed.
      var pause = Boolean(data.pause) || false;

      $carousel.carousel({
        interval: Number(data.interval) || 5000
      });

      if (pause) {
        $carousel.carousel('pause');
      }

      // EVENT BOOTSTRAP CAROUSEL, see http://getbootstrap.com/javascript/#carousel-events
      $carousel.on('slid.bs.carousel', function () {
        var $theCarousel = $(this);
        var $slides = $theCarousel.find('.item');
        var $activeSlide = $theCarousel.find('.item.active');
        var index = $slides.index($activeSlide);
        var $pagination = $theCarousel.find(".cm-carousel__pagination-index");
        //set pagination
        $pagination.text(String(index + 1));
        //reload responsive image. hidden slides had no image because of height/width=0
        $theCarousel.find(".carousel-inner .cm-image--responsive").responsiveImages();
      });

    });
  };

  // --- DOCUMENT READY ---
  $(function () {
    $('[data-cm-carousel]').cmCarousel();
  });

})(jQuery || coremedia.blueprint.$);
